package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static final String SHARED_PREF_NAME = "MyAppP";
    private static final String KEY_NAME = "MyAppP";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText etn = findViewById(R.id.etn);
        Button btnsave = findViewById(R.id.btnsave);
        Button btnload = findViewById(R.id.btnload);
        Button btnclear = findViewById(R.id.btnclear);
        TextView tvdisplay = findViewById(R.id.tvdisplay);

        SharedPreferences sm = getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);

        btnsave.setOnClickListener(view -> {
            String n=etn.getText().toString();
            SharedPreferences.Editor editor = sm.edit();
            editor.putString(KEY_NAME, n);
            editor.apply();
            tvdisplay.setText("Data Saved");
        });
        btnload.setOnClickListener(view -> {
            String n=sm.getString(KEY_NAME, "No Name Found");
            tvdisplay.setText("the store value is : " + n);
        });
        btnclear.setOnClickListener(view -> {
            SharedPreferences.Editor editor = sm.edit();
            editor.clear();
            editor.apply();
            tvdisplay.setText("Data Cleared");
        });
    }
}